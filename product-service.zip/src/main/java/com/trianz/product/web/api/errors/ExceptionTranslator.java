package com.trianz.product.web.api.errors;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.context.request.WebRequest;


import java.io.IOException;
import java.util.Date;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ExceptionTranslator extends ResponseEntityExceptionHandler {

	@ExceptionHandler(BadRequestAlertException.class)
	public ResponseEntity<CustomErrorResponse> customHandleNotFound(BadRequestAlertException ex, WebRequest request) {
		CustomErrorResponse errors = new CustomErrorResponse();
		errors.setTimestamp(LocalDateTime.now());
		errors.setStatus(HttpStatus.BAD_REQUEST.value());
		errors.setError(ex.getErrorKey());
		errors.setMessage(ex.getMessage());
			return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<CustomErrorResponse> resourceHandleNotFound(ResourceNotFoundException ex, WebRequest request) {
		CustomErrorResponse errors = new CustomErrorResponse();
		errors.setTimestamp(LocalDateTime.now());
		errors.setStatus(HttpStatus.NOT_FOUND.value());
		errors.setError(HttpStatus.NOT_FOUND.toString());
		errors.setMessage(ex.getMessage());
			return new ResponseEntity<>(errors, HttpStatus.NOT_FOUND);
	}

}
package com.trianz.product.domain;

import jakarta.persistence.*;

@Entity
@Table(name="Product")
public class Product implements java.io.Serializable {

	private Long id;
	private String productName;

	private Long productQuantity;
	private Double productCost;


	public void setId(Long id){
 	this.id = id;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "Product_Sequence")
	@SequenceGenerator(name = "Product_Sequence", sequenceName = "Product_SEQ")
	public Long getId(){
 	return this.id;
	}

	@Basic
	@Column(name = "product_name")
	public String getProductName(){
		return this.productName;
	}

	public void setProductName(String productName){
 		this.productName = productName;
	}

	@Basic
	@Column(name = "product_quantity")
	public Long getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(Long productQuantity) {
		this.productQuantity = productQuantity;
	}

	@Basic
	@Column(name = "product_cost")
	public Double getProductCost(){
		return this.productCost;
	}

	public void setProductCost(Double productCost){
 		this.productCost = productCost;
	}

}
package com.trianz.product.service;

import java.util.List;
import java.net.URISyntaxException;

import org.springframework.http.ResponseEntity;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.Optional;

import com.trianz.product.domain.Product;

@Service
public interface ProductService{

 Product createProduct(Product product) throws URISyntaxException;
 Product updateProduct(Product product) throws URISyntaxException;
 List<Product> getAllProduct();
Product getProduct(Long id);
 void deleteById(Long id);
}
package com.trianz.product.web.api;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trianz.product.domain.Product;
import com.trianz.product.service.ProductService;

import com.trianz.product.web.api.util.HeaderUtil;
import com.trianz.product.web.api.errors.BadRequestAlertException;
import com.trianz.product.web.api.errors.ResourceNotFoundException;

@RestController
@RequestMapping("/api")
public class ProductAPI{

	private final Logger log = LoggerFactory.getLogger(ProductAPI.class);
	private final ProductService productService;	private static final String ENTITY_NAME ="Product";

	public ProductAPI(ProductService productService) {
		this.productService = productService;
}

	@PostMapping("/product")
	public ResponseEntity<Product> createProduct(@RequestBody Product product) throws URISyntaxException {
		if(product.getId() != null) {
			throw new BadRequestAlertException("A new product cannot already have an ID", ENTITY_NAME,"id exists");
		}
		Product result = this.productService.createProduct(product);
		return ResponseEntity.created(new URI("/api/product/"+ result.getId()))
		.headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
		.body(result);
	}

	@PutMapping("/product")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) throws URISyntaxException {
		if(product.getId() == null) {
			throw new BadRequestAlertException("Invalid id", ENTITY_NAME,"id null");
		}

		Product result = this.productService.updateProduct(product);

		return ResponseEntity.ok()
		.headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, result.getId().toString()))
		.body(result);
	}

	@GetMapping("/product")
	public List<Product> getAllProduct() {
		log.info("REST request to get all products");
		return  this.productService.getAllProduct();
	}

	@GetMapping("/product/{id}")
	public ResponseEntity<Product> getProduct(@PathVariable Long id) {
		log.info("REST request to get product : {}", id);
Product product = productService.getProduct(id);
		return ResponseEntity.accepted().body(product);
	}

	@DeleteMapping("/product/{id}")
	public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
		log.info("REST request to delete product : {}", id);
		productService.deleteById(id);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
	}

}
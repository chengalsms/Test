package com.trianz.product.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trianz.product.domain.Product;
import com.trianz.product.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	private final Logger log = LoggerFactory.getLogger(ProductServiceImpl.class);
	private static final String ENTITY_NAME ="Product";
	private final ProductRepository productRepository;

	public ProductServiceImpl(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@Override
	public Product createProduct(Product product) throws URISyntaxException{
		Product result = productRepository.save(product);
		return result;
	}

	@Override
	public Product updateProduct(Product product) throws URISyntaxException{
		Product result = productRepository.save(product);
		return result;
	}

	@Override
	public Product getProduct(Long id){
		Optional<Product> product = productRepository.findById(id);
		return product.get();
	}

	@Override
	public List<Product> getAllProduct(){
		return productRepository.findAll();
	}

	@Override
	public void deleteById(Long id) {
		productRepository.deleteById(id);
 }
}